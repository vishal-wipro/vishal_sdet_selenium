package sel_ol;

import org.openqa.selenium.By;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.Select;

public class esp {

	WebDriver driver;
	//private static XSSFWorkbook wb;
	public static void main(String args[])
	{
		WebDriver driver;
		try
		{
			System.setProperty("webdriver.chrome.driver","C:\\\\Users\\\\Vishal Vincent\\\\Desktop\\\\jarfiles\\\\chromedriver.exe");
			driver= new ChromeDriver();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			//site opens
			driver.get("https://www.olay.es/es-es");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//a[contains(text(),'Registro')]")).click();
			Thread.sleep(3000);
			driver.findElement(By.id("phdesktopbody_0_imgmale")).click();
			Thread.sleep(1000);
			driver.findElement(By.id("phdesktopbody_0_grs_consumer[firstname]")).sendKeys("Martin");
			Thread.sleep(1000);
		     driver.findElement(By.id("phdesktopbody_0_grs_consumer[lastname]")).sendKeys("Kumbin");
		    Thread.sleep(1000);
		    js.executeScript("window.scrollBy(0,500)");
		    
		    
		//excel read
		   ArrayList<String> ar=new ArrayList<String>();
		    
		    //provide your own system path
			FileInputStream fs=new FileInputStream("C:\\Users\\Vishal Vincent\\Downloads\\espaniol_sel_vishal.xlsx");
			
			XSSFWorkbook wb=new XSSFWorkbook(fs);
			XSSFSheet st=wb.getSheetAt(0);
			String username=st.getRow(1).getCell(0).getStringCellValue();
		
		   driver.findElement(By.id("phdesktopbody_0_grs_account[emails][0][address]")).sendKeys(username);
		    Thread.sleep(1000);
		    //password
		    driver.findElement(By.id("phdesktopbody_0_grs_account[password][password]")).sendKeys("cas@Dsg12.com");
		    Thread.sleep(1000);
		    driver.findElement(By.id("phdesktopbody_0_grs_account[password][confirm]")).sendKeys("cas@Dsg12.com");
		    Thread.sleep(1000);
		    js.executeScript("window.scrollBy(0,400)");
		    Select dropdown=new Select(driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][day]")));
		    dropdown.selectByVisibleText("17");
		    Thread.sleep(1000);
		    dropdown=new Select(driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][month]")));
		    dropdown.selectByVisibleText("8");
		    Thread.sleep(1000);
		    dropdown=new Select(driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][year]")));
		    dropdown.selectByVisibleText("1994");
		    js.executeScript("window.scrollBy(0,400)");
			
		    Thread.sleep(500);
			driver.findElement(By.id("phdesktopbody_0_submit")).click();
		    Thread.sleep(1000);			
		    driver. quit();
		}
 catch (Exception e) 
	{
		e.printStackTrace();
	}
		
	
	}}
