package sel_ol;

import org.openqa.selenium.By;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.Select;



public class eng {

	WebDriver driver;
	public void eng__olay()
	{
		try
		{
			System.setProperty("webdriver.chrome.driver","C:\\\\Users\\\\Vishal Vincent\\\\Desktop\\\\jarfiles\\\\chromedriver.exe");
			driver= new ChromeDriver();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			//site opens
			driver.get("https://www.olay.co.uk/en-gb");
			Thread.sleep(9000);
			driver.findElement(By.xpath("//a[contains(text(),'Register')]")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[emails][0][address]\"]")).sendKeys("abc@gmail.com");
			Thread.sleep(1000);
		    //driver.findElement(By.xpath("//input[@id='phdesktopbody_0_grs_account[password]")).sendKeys("Olay_pass1234");
		    driver.findElement(By.id("phdesktopbody_0_grs_account[password][password]")).sendKeys("Olay_pass1234");
		    Thread.sleep(1000);
		    driver.findElement(By.id("phdesktopbody_0_grs_account[password][confirm]")).sendKeys("Olay_pass1234");
		    Thread.sleep(1000);
		    Select dropdown=new Select(driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][day]")));
		    dropdown.selectByVisibleText("17");
		    Thread.sleep(1000);
		    dropdown=new Select(driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][month]")));
		    dropdown.selectByVisibleText("8");
		    Thread.sleep(1000);
		    dropdown=new Select(driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][year]")));
		    dropdown.selectByVisibleText("1994");
		    Thread.sleep(1000);
			js.executeScript("window.scrollBy(0,1000)");
		    
			driver.findElement(By.id("phdesktopbody_0_submit")).click();
			
			driver. quit();
					
		}
 catch (Exception e) 
	{
		e.printStackTrace();
	}}
	
	
		
	public static void main(String args[]) {
			
		eng m=new eng();
		m.eng__olay();		
		}
}
