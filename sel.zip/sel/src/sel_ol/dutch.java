package sel_ol;

import org.openqa.selenium.By;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.Select;
import java.util.Random;
public class dutch {
	
	public static void main(String args[])
	{
		Random rand = new Random(); //instance of random class
	      int upperbound = 8;
	        //generate random values from 0-24
	      int int_random = rand.nextInt(upperbound); 
	     String arr[]=new String[] {"hsaf@gjw.com","gjagfhd@uy123iy.com","gjha213gsdhs@saf.com","dadsd243sas@asdda.com","hs234af@gjw.com","gjagf123hd@uyiy.com","gjh123agsdhs@saf.com","da321dsdassas@asdda.com"};
	     
		WebDriver driver;
		try
		{
			System.setProperty("webdriver.chrome.driver","C:\\Users\\Vishal Vincent\\Desktop\\jarfiles\\chromedriver.exe");
			driver= new ChromeDriver();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			//site opens
			driver.get("https://www.olaz.de/de-de");
			Thread.sleep(9000);
			driver.findElement(By.xpath("//a[contains(text(),'Registrieren')]")).click();
			Thread.sleep(3000);
			driver.findElement(By.id("phdesktopbody_0_imgmale")).click();
			Thread.sleep(1000);
			js.executeScript("window.scrollBy(0,200)");
			driver.findElement(By.id("phdesktopbody_0_grs_consumer[firstname]")).sendKeys("Mart");
			Thread.sleep(1000);
		     driver.findElement(By.id("phdesktopbody_0_grs_consumer[lastname]")).sendKeys("Kumb");
		    Thread.sleep(1000);
		    String email=(upperbound-1) + arr[int_random];
		    driver.findElement(By.id("phdesktopbody_0_grs_account[emails][0][address]")).sendKeys(email);
		    Thread.sleep(1000);
		    //password
		    driver.findElement(By.id("phdesktopbody_0_grs_account[password][password]")).sendKeys("cas@Dsg12.com");
		    Thread.sleep(1000);
		    driver.findElement(By.id("phdesktopbody_0_grs_account[password][confirm]")).sendKeys("cas@Dsg12.com");
		    
		    
		   // js.executeScript("window.scrollBy(0,200)");
		    
		    
		    //date
		    Select dropdown=new Select(driver.findElement(By.xpath("//select[@name='phdesktopbody_0$ctl72']")));
		    dropdown.selectByVisibleText("17");
		    Thread.sleep(1000);
		    dropdown=new Select(driver.findElement(By.xpath("//select[@name='phdesktopbody_0$ctl74']")));
		    dropdown.selectByVisibleText("8");
		    Thread.sleep(1000);
		    dropdown=new Select(driver.findElement(By.xpath("//select[@name='phdesktopbody_0$ctl76']")));
		    dropdown.selectByVisibleText("1994");
		    Thread.sleep(1000);
		    dropdown=new Select(driver.findElement(By.id("phdesktopbody_0_labelgrs_account[addresses][0][country]")));
		    dropdown.selectByVisibleText("Deutschland");
		    Thread.sleep(1000);
			js.executeScript("window.scrollBy(0,200)");
			
			driver.findElement(By.id("phdesktopbody_0_labelgrs_account[addresses][0][line1]")).sendKeys("lords Home 124");
		    Thread.sleep(1000);
		   // driver.findElement(By.id("phdesktopbody_0_grs_account[addresses][0][postalarea]")).sendKeys("111444");
		    //Thread.sleep(1000);
		    js.executeScript("window.scrollBy(0,100)");
			driver.findElement(By.id("phdesktopbody_0_labelgrs_account[addresses][0][city]")).sendKeys("Dutch");
			Thread.sleep(1000);
			js.executeScript("window.scrollBy(0,200)");
			driver.findElement(By.id("phdesktopbody_0_submit")).click();
			
			driver. quit();	
		}
 catch (Exception e) 
	{
		e.printStackTrace();
	}}

}
