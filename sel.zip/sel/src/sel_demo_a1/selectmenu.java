package sel_demo_a1;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class selectmenu {

	 WebDriver driver;
     public static void main(String args[])
	{
		WebDriver driver;
		try
		{
			System.setProperty("webdriver.chrome.driver","C:\\\\Users\\\\Vishal Vincent\\\\Desktop\\\\jarfiles\\\\chromedriver.exe");
			driver= new ChromeDriver();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			
			  driver.get("http://demoqa.com/selectmenu/");
		
		}
		
		catch (Exception e) 
		{
			e.printStackTrace();

		}
	}
}
