package sel_demo_a1;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.By;

public class demoqa_drag {
	WebDriver driver;
	public static void main(String []  args)
	{
		WebDriver driver;
		try {
			System.setProperty("webdriver.chrome.driver","C:\\\\Users\\\\Vishal Vincent\\\\Desktop\\\\jarfiles\\\\chromedriver.exe");
			driver= new ChromeDriver();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			//site opens
			  driver.get("http://demoqa.com/droppable/");
			  Thread.sleep(2000);
			//Element which needs to drag.    		
	        	WebElement From=driver.findElement(By.id("draggable"));	
	         
	         //Element on which need to drop.		
	         WebElement To=driver.findElement(By.id("droppable"));					
	         		
	         //Using Action class for drag and drop.		
	         Actions act=new Actions(driver);					

		//Dragged and dropped.		
	         act.dragAndDrop(From, To).build().perform();	
	         if(driver.getPageSource().contains("Dropped!")){
	        	 System.out.println("Text is present");
	        	 }else{
	        	 System.out.println("Text is absent");
	        	 }
	        	 
	         driver. quit();
			  
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
		
}}
