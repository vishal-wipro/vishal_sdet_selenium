package sel_demo_a1;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class demo_selectable {
	 
	  WebDriver driver;
     public static void main(String args[])
	{
    	 
		WebDriver driver;
		
		try
		{
			System.setProperty("webdriver.chrome.driver","C:\\\\Users\\\\Vishal Vincent\\\\Desktop\\\\jarfiles\\\\chromedriver.exe");
			driver= new ChromeDriver();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			
			  driver.get("http://demoqa.com/selectable/");
			 //list 
			  WebElement lst=driver.findElement(By.id("demo-tab-list"));
			  System.out.println(lst.getText());
			  Thread.sleep(2000);
			driver.findElement(By.id("demo-tab-list")).click();Thread.sleep(1000);
			//1
			 WebElement a=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/ul[1]/li[1]"));
			  System.out.println(a.getText());
			  Thread.sleep(2000);
			driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/ul[1]/li[1]")).click();
			  //2
			 WebElement b=driver.findElement(By.xpath("//li[contains(text(),'Dapibus ac facilisis in')]"));
			  System.out.println(b.getText());
			  Thread.sleep(2000);
			driver.findElement(By.xpath("//li[contains(text(),'Dapibus ac facilisis in')]")).click();
			  //3
			 WebElement c=driver.findElement(By.xpath("//li[contains(text(),'Morbi leo risus')]"));
			  System.out.println(c.getText());
			  Thread.sleep(2000);
			driver.findElement(By.xpath("//li[contains(text(),'Morbi leo risus')]")).click();
			//4
			WebElement d=driver.findElement(By.xpath("//li[contains(text(),'Porta ac consectetur ac')]"));
			  System.out.println(d.getText());
			  Thread.sleep(2000);
			driver.findElement(By.xpath("//li[contains(text(),'Porta ac consectetur ac')]")).click();
			 
			//GRID
			WebElement g=driver.findElement(By.xpath("//a[@id='demo-tab-grid']"));
			  System.out.println(g.getText());
			  Thread.sleep(2000);
			driver.findElement(By.xpath("//a[@id='demo-tab-grid']")).click();
			 
			//1
			 WebElement aa=driver.findElement(By.xpath("//li[contains(text(),'One')]"));
			  System.out.println(aa.getText());
			  Thread.sleep(2000);
			driver.findElement(By.xpath("//li[contains(text(),'One')]")).click();
			  //2
			 WebElement bb=driver.findElement(By.xpath("//li[contains(text(),'Two')]"));
			  System.out.println(bb.getText());
			  Thread.sleep(2000);
			driver.findElement(By.xpath("//li[contains(text(),'Two')]")).click();
			  //3
			 WebElement cc=driver.findElement(By.xpath("//li[contains(text(),'Three')]"));
			  System.out.println(cc.getText());
			  Thread.sleep(2000);
			driver.findElement(By.xpath("//li[contains(text(),'Three')]")).click();
			//4
			WebElement dd=driver.findElement(By.xpath("//li[contains(text(),'Four')]"));
			  System.out.println(dd.getText());
			  Thread.sleep(2000);
			driver.findElement(By.xpath("//li[contains(text(),'Four')]")).click();
			//5
			WebElement ee=driver.findElement(By.xpath("//li[contains(text(),'Five')]"));
			  System.out.println(ee.getText());
			  Thread.sleep(2000);
			driver.findElement(By.xpath("//li[contains(text(),'Five')]")).click();
			//6
			WebElement ff=driver.findElement(By.xpath("//li[contains(text(),'Six')]"));
			  System.out.println(ff.getText());
			  Thread.sleep(2000);
			driver.findElement(By.xpath("//li[contains(text(),'Six')]")).click();
			  
			  
			  
			  
			  
			  WebElement elemnt=driver.findElement(By.xpath("//div[contains(text(),'Elements')]"));
			  System.out.println(elemnt.getText());
			  Thread.sleep(2000);
			  driver.findElement(By.xpath("//div[contains(text(),'Elements')]")).click();
			 
			  //under ELEMENTS 
	//textbox		  
			  WebElement txtbox=driver.findElement(By.xpath("//span[contains(text(),'Text Box')]"));
			  System.out.println(txtbox.getText());
			  Thread.sleep(2000);
			  driver.findElement(By.xpath("//span[contains(text(),'Text Box')]")).click();Thread.sleep(1000);
			  driver.navigate().back();
				
	//Checkbooks
				driver.findElement(By.xpath("//div[contains(text(),'Elements')]")).click();
				WebElement chkbx=driver.findElement(By.xpath("//span[contains(text(),'Check Box')]"));
				 System.out.println(chkbx.getText());  
				 Thread.sleep(2000);
				driver.findElement(By.xpath("//span[contains(text(),'Check Box')]")).click();Thread.sleep(1000);
				driver.navigate().back();
				 
					
		//radiobutton	
					driver.findElement(By.xpath("//div[contains(text(),'Elements')]")).click();
					WebElement rdbtn=driver.findElement(By.xpath("//span[contains(text(),'Radio Button')]"));
					  System.out.println(rdbtn.getText());
					  Thread.sleep(2000);
					driver.findElement(By.xpath("//span[contains(text(),'Radio Button')]")).click();Thread.sleep(1000);
					driver.navigate().back();
					
js.executeScript("window.scrollBy(0,200)");

			//webtables		
					driver.findElement(By.xpath("//div[contains(text(),'Elements')]")).click();
					WebElement wbtbl=driver.findElement(By.xpath("//span[contains(text(),'Web Tables')]"));
					  System.out.println(wbtbl.getText());
					  Thread.sleep(2000);
					driver.findElement(By.xpath("//span[contains(text(),'Web Tables')]")).click();Thread.sleep(1000);
					driver.navigate().back();
					js.executeScript("window.scrollBy(0,200)");
			//buttons		
					driver.findElement(By.xpath("//div[contains(text(),'Elements')]")).click();
					WebElement btn=driver.findElement(By.xpath("//span[contains(text(),'Buttons')]"));
					  System.out.println(btn.getText());
					  Thread.sleep(2000);
					driver.findElement(By.xpath("//span[contains(text(),'Buttons')]")).click();Thread.sleep(1000);
					driver.navigate().back();
					js.executeScript("window.scrollBy(0,200)");
			//links		
					driver.findElement(By.xpath("//div[contains(text(),'Elements')]")).click();
					WebElement lnk=driver.findElement(By.xpath("//span[contains(text(),'Links')]"));
					  System.out.println(lnk.getText());
					  Thread.sleep(2000);
					driver.findElement(By.xpath("//span[contains(text(),'Links')]")).click();Thread.sleep(1000);
					driver.navigate().back();
					js.executeScript("window.scrollBy(0,200)");
			//uplddwnld	
					driver.findElement(By.xpath("//div[contains(text(),'Elements')]")).click();
					WebElement updw=driver.findElement(By.xpath("//span[contains(text(),'Upload and Download')]"));
					  System.out.println(updw.getText());
					  Thread.sleep(2000);
					driver.findElement(By.xpath("//span[contains(text(),'Upload and Download')]")).click();Thread.sleep(1000);
					driver.navigate().back();
					js.executeScript("window.scrollBy(0,200)");
			//dynmcpro	
					driver.findElement(By.xpath("//div[contains(text(),'Elements')]")).click();
					WebElement dpro=driver.findElement(By.xpath("//span[contains(text(),'Dynamic Properties')]"));
					  System.out.println(dpro.getText());
					  Thread.sleep(2000);
					driver.findElement(By.xpath("//span[contains(text(),'Dynamic Properties')]")).click();Thread.sleep(1000);
					driver.navigate().back();
					js.executeScript("window.scrollBy(0,200)");
			//under Forms	
					 WebElement frms=driver.findElement(By.xpath("//div[contains(text(),'Forms')]"));
					  System.out.println(frms.getText());
					  Thread.sleep(2000);
					  driver.findElement(By.xpath("//div[contains(text(),'Forms')]")).click();
					  //practice_form
					  WebElement pfor=driver.findElement(By.xpath("//span[contains(text(),'Practice Form')]"));
						  System.out.println(pfor.getText());
						  //Thread.sleep(2000);
						driver.findElement(By.xpath("//span[contains(text(),'Practice Form')]")).click();Thread.sleep(1000);
						driver.navigate().back();
						js.executeScript("window.scrollBy(0,200)");
						//alerts
						  WebElement al=driver.findElement(By.xpath("//div[contains(text(),'Alerts, Frame & Windows')]"));
							  System.out.println(al.getText());
							 // Thread.sleep(2000);
							driver.findElement(By.xpath("//div[contains(text(),'Alerts, Frame & Windows')]")).click();Thread.sleep(500);
							driver.findElement(By.xpath("//div[contains(text(),'Alerts, Frame & Windows')]")).click();
							//widgets
							  WebElement w=driver.findElement(By.xpath("//div[contains(text(),'Widgets')]"));
								  System.out.println(w.getText());
								 // Thread.sleep(2000);
								driver.findElement(By.xpath("//div[contains(text(),'Widgets')]")).click();Thread.sleep(500);
								driver.findElement(By.xpath("//div[contains(text(),'Widgets')]")).click();
								//interaction
								  WebElement i=driver.findElement(By.xpath("//div[contains(text(),'Interactions')]"));
									  System.out.println(i.getText());
									 // Thread.sleep(2000);
									driver.findElement(By.xpath("//div[contains(text(),'Interactions')]")).click();Thread.sleep(500);
									driver.findElement(By.xpath("//div[contains(text(),'Interactions')]")).click();
									//bookstoreapp
									  WebElement bs=driver.findElement(By.xpath("//div[contains(text(),'Book Store Application')]"));
										  System.out.println(bs.getText());
						
										driver.findElement(By.xpath("//div[contains(text(),'Book Store Application')]")).click();Thread.sleep(500);
										driver.findElement(By.xpath("//div[contains(text(),'Book Store Application')]")).click();
										
										driver. quit();
						
						
					 }
		
		catch (Exception e) 
		{
			e.printStackTrace();

		}
		
	}
}
 
