package sel_mmt_a3;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class mmt {
	WebDriver driver;{
		//public void invokeBrowser()
		//{
			try
			{
				System.setProperty("webdriver.chrome.driver","C:\\Users\\Vishal Vincent\\Desktop\\jarfiles\\chromedriver.exe");
				driver= new ChromeDriver();
				driver.manage().deleteAllCookies();
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
				//site opens
				driver.get("https://www.makemytrip.com/");
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//li[contains(text(),'Round Trip')]")).click();
	            //From
	            driver.findElement(By.xpath("//input[@id='fromCity']")).click();
	            driver.findElement(By.xpath("//input[@placeholder='From']")).sendKeys("Chennai");
	            
	            Thread.sleep(3000);
	            driver.findElement(By.xpath("//input[@placeholder='From']")).sendKeys(Keys.ARROW_DOWN);
	            driver.findElement(By.xpath("//input[@placeholder='From']")).sendKeys(Keys.ENTER);
	            //To
	            driver.findElement(By.xpath("//input[@placeholder='To']")).sendKeys("Ranchi");
	            Thread.sleep(3000);
	            driver.findElement(By.xpath("//input[@placeholder='To']")).sendKeys(Keys.ARROW_DOWN);
	            driver.findElement(By.xpath("//input[@placeholder='To']")).sendKeys(Keys.ENTER);
	            //from date
	            driver.findElement(By.xpath("//div[@class='DayPicker-Months']//div[2]//div[3]//div[4]//div[2]//div[1]//p[1]")).click();
		        //to date
	            driver.findElement(By.xpath("//div[@class='DayPicker-Day']//p[contains(text(),'31')]")).click();
	            driver.findElement(By.xpath("//a[contains(@class,'primaryBtn font24 latoBold widgetSearchBtn')]")).click();
	            
	            Thread.sleep(5000);
	            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	            //getting lowest price
	            driver.findElement(By.xpath("//button[@id='sorter_btn_onward']//i[@class='dropdown_arrow']")).click();
	            driver.findElement(By.xpath("//div[contains(@class,'dropdown pull-right c-dropdown sortby-dropdown open')]//a[@class='make_flex active']")).click();
	            driver.findElement(By.xpath("//button[@id='sorter_btn_return']//i[@class='dropdown_arrow']")).click();
	            driver.findElement(By.xpath	("//div[contains(@class,'dropdown pull-right c-dropdown sortby-dropdown open')]//a[@class='make_flex active']")).click();
	            //selecting flight
	            Thread.sleep(4000);
	           driver.findElement(By.xpath("//span[@class='cursor_pointer chevron-down']")).click();
	            
	            driver.findElement(By.id("//button[contains(@class,'fli_primary_btn text-uppercase')]")).click();
	            driver. quit();
			}
			
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		}}

